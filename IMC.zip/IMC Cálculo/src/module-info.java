module ex12 {
}